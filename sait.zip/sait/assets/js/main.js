// Основной JavaScript для сайта PetFood

document.addEventListener('DOMContentLoaded', function() {
    // Мобильное меню
    const menuToggle = document.querySelector('.menu-toggle');
    const navMenu = document.querySelector('.nav-menu');
    
    if (menuToggle && navMenu) {
        menuToggle.addEventListener('click', function() {
            navMenu.classList.toggle('active');
            menuToggle.innerHTML = navMenu.classList.contains('active') 
                ? '<i class="fas fa-times"></i>' 
                : '<i class="fas fa-bars"></i>';
        });
        
        // Закрытие меню при клике на ссылку
        const navLinks = document.querySelectorAll('.nav-menu a');
        navLinks.forEach(link => {
            link.addEventListener('click', function() {
                navMenu.classList.remove('active');
                menuToggle.innerHTML = '<i class="fas fa-bars"></i>';
            });
        });
    }
    
    // Плавная прокрутка для якорных ссылок
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function(e) {
            const href = this.getAttribute('href');
            
            if (href === '#') return;
            
            const targetElement = document.querySelector(href);
            if (targetElement) {
                e.preventDefault();
                window.scrollTo({
                    top: targetElement.offsetTop - 80,
                    behavior: 'smooth'
                });
            }
        });
    });
    
    // Форматирование телефона
    const phoneInput = document.getElementById('phone');
    if (phoneInput) {
        phoneInput.addEventListener('input', function(e) {
            let value = this.value.replace(/\D/g, '');
            
            if (value.length > 0) {
                if (value[0] === '7' || value[0] === '8') {
                    value = '+7 ' + value.substring(1);
                } else if (value[0] === '9') {
                    value = '+7 ' + value;
                }
                
                if (value.length > 4) {
                    value = value.substring(0, 4) + ' (' + value.substring(4);
                }
                if (value.length > 8) {
                    value = value.substring(0, 8) + ') ' + value.substring(8);
                }
                if (value.length > 13) {
                    value = value.substring(0, 13) + '-' + value.substring(13);
                }
                if (value.length > 16) {
                    value = value.substring(0, 16) + '-' + value.substring(16);
                }
            }
            
            this.value = value;
        });
    }
    
    // Валидация формы при отправке
    const orderForm = document.getElementById('orderForm');
    if (orderForm) {
        orderForm.addEventListener('submit', function(e) {
            let isValid = true;
            const requiredFields = this.querySelectorAll('[required]');
            
            requiredFields.forEach(field => {
                if (!field.value.trim()) {
                    isValid = false;
                    field.style.borderColor = 'var(--danger-color)';
                    
                    // Добавляем сообщение об ошибке
                    let errorMsg = field.nextElementSibling;
                    if (!errorMsg || !errorMsg.classList.contains('error-message')) {
                        errorMsg = document.createElement('div');
                        errorMsg.className = 'error-message';
                        errorMsg.style.color = 'var(--danger-color)';
                        errorMsg.style.fontSize = '0.9rem';
                        errorMsg.style.marginTop = '5px';
                        errorMsg.textContent = 'Это поле обязательно для заполнения';
                        field.parentNode.insertBefore(errorMsg, field.nextSibling);
                    }
                } else {
                    field.style.borderColor = '';
                    
                    // Удаляем сообщение об ошибке
                    const errorMsg = field.nextElementSibling;
                    if (errorMsg && errorMsg.classList.contains('error-message')) {
                        errorMsg.remove();
                    }
                }
            });
            
            if (!isValid) {
                e.preventDefault();
                alert('Пожалуйста, заполните все обязательные поля, отмеченные *');
            }
        });
    }
    
    // Счетчик для количества мешков
    const bagsCountInput = document.getElementById('bags_count');
    if (bagsCountInput) {
        const min = parseInt(bagsCountInput.min) || 1;
        const max = parseInt(bagsCountInput.max) || 100;
        
        // Создаем кнопки +/-
        const container = bagsCountInput.parentNode;
        const controls = document.createElement('div');
        controls.className = 'number-controls';
        controls.style.display = 'flex';
        controls.style.gap = '10px';
        controls.style.marginTop = '10px';
        
        const minusBtn = document.createElement('button');
        minusBtn.type = 'button';
        minusBtn.innerHTML = '<i class="fas fa-minus"></i>';
        minusBtn.className = 'btn btn-secondary';
        minusBtn.style.padding = '5px 15px';
        
        const plusBtn = document.createElement('button');
        plusBtn.type = 'button';
        plusBtn.innerHTML = '<i class="fas fa-plus"></i>';
        plusBtn.className = 'btn btn-secondary';
        plusBtn.style.padding = '5px 15px';
        
        controls.appendChild(minusBtn);
        controls.appendChild(bagsCountInput.cloneNode(true));
        const newInput = controls.lastChild;
        bagsCountInput.replaceWith(controls);
        
        minusBtn.addEventListener('click', function() {
            let value = parseInt(newInput.value) || min;
            if (value > min) {
                newInput.value = value - 1;
            }
        });
        
        plusBtn.addEventListener('click', function() {
            let value = parseInt(newInput.value) || min;
            if (value < max) {
                newInput.value = value + 1;
            }
        });
        
        newInput.addEventListener('change', function() {
            let value = parseInt(this.value) || min;
            if (value < min) this.value = min;
            if (value > max) this.value = max;
        });
    }
    
    // Показываем/скрываем пароль
    const passwordInputs = document.querySelectorAll('input[type="password"]');
    passwordInputs.forEach(input => {
        const toggleBtn = document.createElement('button');
        toggleBtn.type = 'button';
        toggleBtn.innerHTML = '<i class="fas fa-eye"></i>';
        toggleBtn.style.position = 'absolute';
        toggleBtn.style.right = '10px';
        toggleBtn.style.top = '50%';
        toggleBtn.style.transform = 'translateY(-50%)';
        toggleBtn.style.background = 'none';
        toggleBtn.style.border = 'none';
        toggleBtn.style.color = '#666';
        toggleBtn.style.cursor = 'pointer';
        
        const wrapper = document.createElement('div');
        wrapper.style.position = 'relative';
        input.parentNode.insertBefore(wrapper, input);
        wrapper.appendChild(input);
        wrapper.appendChild(toggleBtn);
        
        toggleBtn.addEventListener('click', function() {
            if (input.type === 'password') {
                input.type = 'text';
                this.innerHTML = '<i class="fas fa-eye-slash"></i>';
            } else {
                input.type = 'password';
                this.innerHTML = '<i class="fas fa-eye"></i>';
            }
        });
    });
    
    // Анимация при скролле
    const animateOnScroll = function() {
        const elements = document.querySelectorAll('.service-card, .product-card, .stat-card');
        
        elements.forEach(element => {
            const elementTop = element.getBoundingClientRect().top;
            const elementVisible = 150;
            
            if (elementTop < window.innerHeight - elementVisible) {
                element.classList.add('animated');
            }
        });
    };
    
    // Запускаем анимацию при загрузке и скролле
    animateOnScroll();
    window.addEventListener('scroll', animateOnScroll);
    
    // Добавляем класс анимации
    const style = document.createElement('style');
    style.textContent = `
        .service-card, .product-card, .stat-card {
            opacity: 0;
            transform: translateY(20px);
            transition: opacity 0.6s ease, transform 0.6s ease;
        }
        
        .service-card.animated, .product-card.animated, .stat-card.animated {
            opacity: 1;
            transform: translateY(0);
        }
    `;
    document.head.appendChild(style);
});