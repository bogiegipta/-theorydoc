<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PetFood - Заказ кормов для животных</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500;600;700&family=Roboto:wght@300;400;500&display=swap" rel="stylesheet">
</head>
<body>
    <!-- Шапка сайта -->
    <header class="header">
        <div class="container">
            <nav class="navbar">
                <a href="index.php" class="logo">
                    <i class="fas fa-paw"></i>
                    <span>PetFood</span>
                </a>
                
                <ul class="nav-menu">
                    <li><a href="index.php" class="active"><i class="fas fa-home"></i> Главная</a></li>
                    <li><a href="#services"><i class="fas fa-concierge-bell"></i> Услуги</a></li>
                    <li><a href="#products"><i class="fas fa-shopping-basket"></i> Продукция</a></li>
                    <li><a href="#about"><i class="fas fa-info-circle"></i> О нас</a></li>
                    <li><a href="order.php"><i class="fas fa-cart-plus"></i> Заказать</a></li>
                    <li><a href="#contacts"><i class="fas fa-phone"></i> Контакты</a></li>
                </ul>
                
                <div class="nav-actions">
                    <a href="order.php" class="btn btn-primary">
                        <i class="fas fa-bolt"></i> Быстрый заказ
                    </a>
                    <a href="admin/index.php" class="btn btn-secondary">
                        <i class="fas fa-user-shield"></i> Админ
                    </a>
                </div>
                
                <button class="menu-toggle">
                    <i class="fas fa-bars"></i>
                </button>
            </nav>
        </div>
    </header>

    <!-- Герой-секция -->
    <section class="hero">
        <div class="container">
            <div class="hero-content">
                <h1 class="hero-title">Питание для ваших любимцев с доставкой</h1>
                <p class="hero-subtitle">Качественные корма для всех видов домашних животных. Быстрая доставка по городу.</p>
                <div class="hero-actions">
                    <a href="order.php" class="btn btn-primary btn-large">
                        <i class="fas fa-shopping-cart"></i> Оформить заказ
                    </a>
                    <a href="#products" class="btn btn-outline btn-large">
                        <i class="fas fa-search"></i> Выбрать корм
                    </a>
                </div>
            </div>
            <div class="hero-image">
                <img src="https://images.unsplash.com/photo-1576201836106-db1758fd1c97?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80" alt="Домашние животные">
            </div>
        </div>
    </section>

    <!-- Услуги -->
    <section id="services" class="services section">
        <div class="container">
            <h2 class="section-title">Наши услуги</h2>
            <p class="section-subtitle">Мы предлагаем полный спектр услуг для ваших питомцев</p>
            
            <div class="services-grid">
                <div class="service-card">
                    <div class="service-icon">
                        <i class="fas fa-shipping-fast"></i>
                    </div>
                    <h3>Бесплатная доставка</h3>
                    <p>Доставка в день заказа при сумме от 2000₽</p>
                </div>
                
                <div class="service-card">
                    <div class="service-icon">
                        <i class="fas fa-award"></i>
                    </div>
                    <h3>Качественные корма</h3>
                    <p>Только сертифицированная продукция премиум-класса</p>
                </div>
                
                <div class="service-card">
                    <div class="service-icon">
                        <i class="fas fa-headset"></i>
                    </div>
                    <h3>Консультация 24/7</h3>
                    <p>Поможем подобрать корм для вашего питомца</p>
                </div>
                
                <div class="service-card">
                    <div class="service-icon">
                        <i class="fas fa-percentage"></i>
                    </div>
                    <h3>Скидки постоянным клиентам</h3>
                    <p>Накопительная система скидок до 20%</p>
                </div>
            </div>
        </div>
    </section>

    <!-- Продукция -->
    <section id="products" class="products section bg-light">
        <div class="container">
            <h2 class="section-title">Ассортимент кормов</h2>
            <p class="section-subtitle">Широкий выбор кормов для разных видов животных</p>
            
            <div class="products-grid">
                <div class="product-card">
                    <div class="product-image">
                        <i class="fas fa-dog"></i>
                    </div>
                    <h3>Для собак</h3>
                    <ul>
                        <li>Сухой корм премиум класса</li>
                        <li>Влажные корма</li>
                        <li>Лакомства и кости</li>
                        <li>Лечебные корма</li>
                    </ul>
                </div>
                
                <div class="product-card">
                    <div class="product-image">
                        <i class="fas fa-cat"></i>
                    </div>
                    <h3>Для кошек</h3>
                    <ul>
                        <li>Сухой корм премиум класса</li>
                        <li>Паучи и консервы</li>
                        <li>Лакомства</li>
                        <li>Корм для котят</li>
                    </ul>
                </div>
                
                <div class="product-card">
                    <div class="product-image">
                        <i class="fas fa-kiwi-bird"></i>
                    </div>
                    <h3>Для птиц</h3>
                    <ul>
                        <li>Корм для попугаев</li>
                        <li>Корм для канареек</li>
                        <li>Минеральные смеси</li>
                        <li>Лакомства</li>
                    </ul>
                </div>
                
                <div class="product-card">
                    <div class="product-image">
                        <i class="fas fa-fish"></i>
                    </div>
                    <h3>Для рыбок</h3>
                    <ul>
                        <li>Хлопья и гранулы</li>
                        <li>Корм для золотых рыбок</li>
                        <li>Растительные корма</li>
                        <li>Корм для сомов</li>
                    </ul>
                </div>
                
                <div class="product-card">
                    <div class="product-image">
                        <i class="fas fa-rabbit"></i>
                    </div>
                    <h3>Для грызунов</h3>
                    <ul>
                        <li>Корм для кроликов</li>
                        <li>Корм для хомяков</li>
                        <li>Корм для морских свинок</li>
                        <li>Сено и травы</li>
                    </ul>
                </div>
                
                <div class="product-card">
                    <div class="product-image">
                        <i class="fas fa-otter"></i>
                    </div>
                    <h3>Для экзотических животных</h3>
                    <ul>
                        <li>Корм для хорьков</li>
                        <li>Корм для рептилий</li>
                        <li>Корм для земноводных</li>
                        <li>Специальные смеси</li>
                    </ul>
                </div>
            </div>
        </div>
    </section>

    <!-- CTA -->
    <section class="cta">
        <div class="container">
            <h2>Готовы заказать корм для вашего питомца?</h2>
            <p>Заполните форму заказа и получите доставку уже сегодня!</p>
            <a href="order.php" class="btn btn-primary btn-large">
                <i class="fas fa-cart-arrow-down"></i> Перейти к заказу
            </a>
        </div>
    </section>

    <!-- О нас -->
    <section id="about" class="about section">
        <div class="container">
            <div class="about-content">
                <div class="about-text">
                    <h2 class="section-title">О компании PetFood</h2>
                    <p>Мы - команда энтузиастов, которые любят животных и заботятся об их здоровье. Наша миссия - обеспечить ваших питомцев качественным и сбалансированным питанием.</p>
                    <p>Работаем на рынке с 2010 года. За это время мы помогли тысячам владельцев животных подобрать оптимальное питание для их питомцев.</p>
                    
                    <div class="stats">
                        <div class="stat-item">
                            <span class="stat-number">10+</span>
                            <span class="stat-label">лет работы</span>
                        </div>
                        <div class="stat-item">
                            <span class="stat-number">5000+</span>
                            <span class="stat-label">довольных клиентов</span>
                        </div>
                        <div class="stat-item">
                            <span class="stat-number">100+</span>
                            <span class="stat-label">видов кормов</span>
                        </div>
                    </div>
                </div>
                <div class="about-image">
                    <img src="https://images.unsplash.com/photo-1552053831-71594a27632d?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80" alt="Наша команда">
                </div>
            </div>
        </div>
    </section>

    <!-- Контакты -->
    <section id="contacts" class="contacts section bg-light">
        <div class="container">
            <h2 class="section-title">Контакты</h2>
            
            <div class="contacts-grid">
                <div class="contact-info">
                    <div class="contact-item">
                        <i class="fas fa-map-marker-alt"></i>
                        <div>
                            <h3>Адрес</h3>
                            <p>г. Москва, ул. Пушкина, д. 10</p>
                        </div>
                    </div>
                    
                    <div class="contact-item">
                        <i class="fas fa-phone"></i>
                        <div>
                            <h3>Телефон</h3>
                            <p>+7 (495) 123-45-67</p>
                        </div>
                    </div>
                    
                    <div class="contact-item">
                        <i class="fas fa-envelope"></i>
                        <div>
                            <h3>Email</h3>
                            <p>info@petfood.ru</p>
                        </div>
                    </div>
                    
                    <div class="contact-item">
                        <i class="fas fa-clock"></i>
                        <div>
                            <h3>Время работы</h3>
                            <p>Пн-Пт: 9:00 - 20:00</p>
                            <p>Сб-Вс: 10:00 - 18:00</p>
                        </div>
                    </div>
                </div>
                
                <div class="map-placeholder">
                    <div class="map">
                        <i class="fas fa-map-marked-alt"></i>
                        <p>Карта расположения</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Подвал -->
    <footer class="footer">
        <div class="container">
            <div class="footer-content">
                <div class="footer-section">
                    <a href="index.php" class="logo">
                        <i class="fas fa-paw"></i>
                        <span>PetFood</span>
                    </a>
                    <p>Качественные корма для ваших питомцев с доставкой на дом.</p>
                    <div class="social-links">
                        <a href="#"><i class="fab fa-vk"></i></a>
                        <a href="#"><i class="fab fa-telegram"></i></a>
                        <a href="#"><i class="fab fa-instagram"></i></a>
                        <a href="#"><i class="fab fa-whatsapp"></i></a>
                    </div>
                </div>
                
                <div class="footer-section">
                    <h3>Меню</h3>
                    <ul>
                        <li><a href="index.php">Главная</a></li>
                        <li><a href="#services">Услуги</a></li>
                        <li><a href="#products">Продукция</a></li>
                        <li><a href="#about">О нас</a></li>
                        <li><a href="order.php">Заказать</a></li>
                    </ul>
                </div>
                
                <div class="footer-section">
                    <h3>Полезные ссылки</h3>
                    <ul>
                        <li><a href="#">Доставка и оплата</a></li>
                        <li><a href="#">Гарантия качества</a></li>
                        <li><a href="#">Скидки и акции</a></li>
                        <li><a href="#">Отзывы</a></li>
                        <li><a href="admin/index.php">Админ-панель</a></li>
                    </ul>
                </div>
                
                <div class="footer-section">
                    <h3>Контакты</h3>
                    <ul>
                        <li><i class="fas fa-phone"></i> +7 (495) 123-45-67</li>
                        <li><i class="fas fa-envelope"></i> info@petfood.ru</li>
                        <li><i class="fas fa-map-marker-alt"></i> г. Москва, ул. Пушкина, д. 10</li>
                    </ul>
                </div>
            </div>
            
            <div class="footer-bottom">
                <p>&copy; 2024 PetFood. Все права защищены.</p>
                <p>Сайт разработан для заказа кормов для животных</p>
            </div>
        </div>
    </footer>

    <script src="js/main.js"></script>
</body>
</html>