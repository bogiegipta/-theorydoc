<?php


define('DEBUG', true);

// Настройки базы данных
define('DB_HOST', 'localhost');
define('DB_NAME', 'y99126qa_petfood');
define('DB_USER', 'y99126qa_petfood');
define('DB_PASS', '@Rjkktl;2');

// Настройки сессии
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Настройки для хостинга
ini_set('display_errors', DEBUG ? 1 : 0);
ini_set('log_errors', 1);
ini_set('error_log', dirname(__FILE__) . '/error_log.txt');

// Устанавливаем временную зону
date_default_timezone_set('Europe/Moscow');
?>