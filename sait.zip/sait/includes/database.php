<?php
// database.php
require_once 'config.php';

class Database {
    private static $connection = null;
    
    public static function getConnection() {
        if (self::$connection === null) {
            try {
                self::$connection = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
                
                if (self::$connection->connect_error) {
                    // Вместо перенаправления выбрасываем исключение
                    throw new Exception("Ошибка подключения к базе данных. Пожалуйста, попробуйте позже.");
                }
                
                self::$connection->set_charset("utf8mb4");
                
                // Проверяем существование таблиц (опционально)
                self::checkTables();
                
            } catch (Exception $e) {
                // Логируем ошибку
                error_log("Database error: " . $e->getMessage());
                
                // В режиме разработки показываем ошибку
                if (defined('DEBUG') && DEBUG) {
                    die("Ошибка базы данных: " . $e->getMessage());
                } else {
                    // В продакшене показываем пользовательское сообщение
                    die("Временно недоступно. Пожалуйста, попробуйте позже.");
                }
            }
        }
        
        return self::$connection;
    }
    
    private static function checkTables() {
        $conn = self::$connection;
        
        // Проверяем таблицу заказов
        $result = $conn->query("SHOW TABLES LIKE 'orders'");
        if ($result->num_rows == 0) {
            // Создаем таблицу orders (если ее нет)
            $conn->query("CREATE TABLE IF NOT EXISTS orders (
                id INT PRIMARY KEY AUTO_INCREMENT,
                food_type VARCHAR(100) NOT NULL,
                pet_type VARCHAR(100) NOT NULL,
                bags_count INT NOT NULL,
                customer_name VARCHAR(200) NOT NULL,
                delivery_address TEXT NOT NULL,
                phone VARCHAR(20) NOT NULL,
                email VARCHAR(100),
                comments TEXT,
                order_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                status ENUM('new', 'processing', 'completed', 'cancelled') DEFAULT 'new',
                INDEX idx_status (status),
                INDEX idx_order_date (order_date),
                INDEX idx_customer_name (customer_name(50)),
                INDEX idx_phone (phone)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
        }
        
        // Проверяем таблицу пользователей
        $result = $conn->query("SHOW TABLES LIKE 'users'");
        if ($result->num_rows == 0) {
            // Создаем таблицу users (если ее нет)
            $conn->query("CREATE TABLE IF NOT EXISTS users (
                id INT PRIMARY KEY AUTO_INCREMENT,
                username VARCHAR(50) UNIQUE NOT NULL,
                password_hash VARCHAR(255) NOT NULL,
                email VARCHAR(100),
                role ENUM('admin', 'manager') DEFAULT 'manager',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                last_login TIMESTAMP NULL,
                INDEX idx_username (username)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
            
            // Добавляем тестового администратора
            $password_hash = password_hash('admin123', PASSWORD_DEFAULT);
            $conn->query("INSERT IGNORE INTO users (username, password_hash, email, role) 
                         VALUES ('admin', '$password_hash', 'admin@petfood.ru', 'admin')");
        }
    }
    
    public static function close() {
        if (self::$connection !== null) {
            self::$connection->close();
            self::$connection = null;
        }
    }
}
?>