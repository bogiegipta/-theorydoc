<?php
// functions.php
require_once 'database.php';

class Functions {
    
    // Проверка авторизации администратора
    public static function isAdminLoggedIn() {
        return isset($_SESSION['admin_logged_in']) && $_SESSION['admin_logged_in'] === true;
    }
    
    // Вход администратора
    public static function adminLogin($username, $password) {
        $conn = Database::getConnection();
        $stmt = $conn->prepare("SELECT * FROM users WHERE username = ?");
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($user = $result->fetch_assoc()) {
            if (password_verify($password, $user['password_hash'])) {
                $_SESSION['admin_logged_in'] = true;
                $_SESSION['admin_id'] = $user['id'];
                $_SESSION['admin_username'] = $user['username'];
                $_SESSION['admin_role'] = $user['role'];
                
                // Обновляем время последнего входа
                $updateStmt = $conn->prepare("UPDATE users SET last_login = NOW() WHERE id = ?");
                $updateStmt->bind_param("i", $user['id']);
                $updateStmt->execute();
                $updateStmt->close();
                
                $stmt->close();
                return true;
            }
        }
        
        $stmt->close();
        return false;
    }
    
    // Выход из системы
    public static function adminLogout() {
        session_destroy();
        session_start();
    }
    
    // Создание нового заказа
    public static function createOrder($data) {
        $conn = Database::getConnection();
        
        // Подготавливаем данные
        $food_type = $data['food_type'];
        $pet_type = $data['pet_type'];
        $bags_count = intval($data['bags_count']);
        $customer_name = $data['customer_name'];
        $delivery_address = $data['delivery_address'];
        $phone = $data['phone'];
        $email = !empty($data['email']) ? $data['email'] : null;
        $comments = !empty($data['comments']) ? $data['comments'] : null;
        
        $stmt = $conn->prepare("INSERT INTO orders 
            (food_type, pet_type, bags_count, customer_name, delivery_address, phone, email, comments) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
        
        $stmt->bind_param(
            "ssisssss",
            $food_type,
            $pet_type,
            $bags_count,
            $customer_name,
            $delivery_address,
            $phone,
            $email,
            $comments
        );
        
        $result = $stmt->execute();
        $orderId = $stmt->insert_id;
        $stmt->close();
        
        return $result ? $orderId : false;
    }
    
    // Получение всех заказов (для админки)
    public static function getOrders($filters = []) {
        $conn = Database::getConnection();
        
        $where = [];
        $params = [];
        $types = '';
        
        if (!empty($filters['status'])) {
            $where[] = "status = ?";
            $params[] = $filters['status'];
            $types .= 's';
        }
        
        if (!empty($filters['search'])) {
            $where[] = "(customer_name LIKE ? OR phone LIKE ? OR delivery_address LIKE ?)";
            $searchTerm = "%{$filters['search']}%";
            $params[] = $searchTerm;
            $params[] = $searchTerm;
            $params[] = $searchTerm;
            $types .= 'sss';
        }
        
        if (!empty($filters['date_from'])) {
            $where[] = "DATE(order_date) >= ?";
            $params[] = $filters['date_from'];
            $types .= 's';
        }
        
        if (!empty($filters['date_to'])) {
            $where[] = "DATE(order_date) <= ?";
            $params[] = $filters['date_to'];
            $types .= 's';
        }
        
        $whereClause = empty($where) ? '' : 'WHERE ' . implode(' AND ', $where);
        
        $query = "SELECT * FROM orders $whereClause ORDER BY order_date DESC";
        
        if (!empty($params)) {
            $stmt = $conn->prepare($query);
            $stmt->bind_param($types, ...$params);
            $stmt->execute();
            $result = $stmt->get_result();
            $orders = $result->fetch_all(MYSQLI_ASSOC);
            $stmt->close();
        } else {
            $result = $conn->query($query);
            $orders = $result->fetch_all(MYSQLI_ASSOC);
        }
        
        return $orders;
    }
    
    // Получение статистики
    public static function getStats() {
        $conn = Database::getConnection();
        $stats = [];
        
        // Общее количество заказов
        $result = $conn->query("SELECT COUNT(*) as total FROM orders");
        $stats['total_orders'] = $result->fetch_assoc()['total'];
        
        // Заказы по статусам
        $result = $conn->query("SELECT status, COUNT(*) as count FROM orders GROUP BY status");
        $stats['by_status'] = [];
        while ($row = $result->fetch_assoc()) {
            $stats['by_status'][$row['status']] = $row['count'];
        }
        
        // Заказы за сегодня
        $result = $conn->query("SELECT COUNT(*) as count FROM orders WHERE DATE(order_date) = CURDATE()");
        $stats['today_orders'] = $result->fetch_assoc()['count'];
        
        // Общая сумма мешков
        $result = $conn->query("SELECT SUM(bags_count) as total_bags FROM orders");
        $row = $result->fetch_assoc();
        $stats['total_bags'] = $row['total_bags'] ?? 0;
        
        return $stats;
    }
    
    // Обновление статуса заказа
    public static function updateOrderStatus($orderId, $status) {
        $conn = Database::getConnection();
        $stmt = $conn->prepare("UPDATE orders SET status = ? WHERE id = ?");
        $stmt->bind_param("si", $status, $orderId);
        $result = $stmt->execute();
        $stmt->close();
        return $result;
    }
    
    // Удаление заказа
    public static function deleteOrder($orderId) {
        $conn = Database::getConnection();
        $stmt = $conn->prepare("DELETE FROM orders WHERE id = ?");
        $stmt->bind_param("i", $orderId);
        $result = $stmt->execute();
        $stmt->close();
        return $result;
    }
    
    // Валидация телефона
    public static function validatePhone($phone) {
        // Убираем все символы кроме цифр
        $phone = preg_replace('/\D/', '', $phone);
        
        // Проверяем длину (10 цифр для России)
        if (strlen($phone) >= 10 && strlen($phone) <= 15) {
            return true;
        }
        return false;
    }
    
    // Валидация email
    public static function validateEmail($email) {
        return filter_var($email, FILTER_VALIDATE_EMAIL);
    }
    
    // Защита от XSS
    public static function sanitize($input) {
        if (is_array($input)) {
            return array_map([self::class, 'sanitize'], $input);
        }
        return htmlspecialchars(trim($input), ENT_QUOTES, 'UTF-8');
    }
    
    // Получение заказа по ID (опционально, для детального просмотра)
    public static function getOrderById($id) {
        $conn = Database::getConnection();
        $stmt = $conn->prepare("SELECT * FROM orders WHERE id = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $result = $stmt->get_result();
        $order = $result->fetch_assoc();
        $stmt->close();
        
        return $order;
    }
}
?>