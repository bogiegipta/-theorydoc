<?php
// check_db.php
error_reporting(E_ALL);
ini_set('display_errors', 1);

$host = 'localhost';
$dbname = 'y99126qa_petfood';
$username = 'y99126qa_petfood';
$password = '@Rjkktl;2';

echo "<h2>Проверка подключения к базе данных</h2>";

// Способ 1: MySQLi
echo "<h3>1. Проверка через MySQLi:</h3>";
try {
    $conn = new mysqli($host, $username, $password, $dbname);
    
    if ($conn->connect_error) {
        echo "Ошибка MySQLi: " . $conn->connect_error;
    } else {
        echo "✓ MySQLi подключение успешно!<br>";
        
        // Проверяем таблицы
        $result = $conn->query("SHOW TABLES");
        echo "Найдено таблиц: " . $result->num_rows . "<br>";
        
        if ($result->num_rows > 0) {
            echo "Список таблиц:<ul>";
            while ($row = $result->fetch_array()) {
                echo "<li>" . $row[0] . "</li>";
            }
            echo "</ul>";
        }
        
        $conn->close();
    }
} catch (Exception $e) {
    echo "Исключение MySQLi: " . $e->getMessage();
}

// Способ 2: PDO
echo "<h3>2. Проверка через PDO:</h3>";
try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    echo "✓ PDO подключение успешно!";
} catch (PDOException $e) {
    echo "Ошибка PDO: " . $e->getMessage();
}
?>