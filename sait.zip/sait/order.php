<?php
require_once 'includes/database.php';
require_once 'includes/functions.php';

$conn = Database::getConnection();
$errors = [];
$success = false;
$orderId = null;

// Данные для выпадающих списков
$food_types = [
    'Сухой корм премиум класса для собак',
    'Сухой корм премиум класса для кошек',
    'Влажный корм для собак',
    'Влажный корм для кошек',
    'Корм для птиц',
    'Корм для грызунов',
    'Корм для рыбок',
    'Корм для экзотических животных',
    'Лечебный корм',
    'Натуральный корм',
    'Лакомства для собак',
    'Лакомства для кошек'
];

$pet_types = [
    'Собака',
    'Кошка',
    'Попугай',
    'Канарейка',
    'Волнистый попугайчик',
    'Хомяк',
    'Морская свинка',
    'Кролик',
    'Шиншилла',
    'Хорек',
    'Черепаха',
    'Рыбки',
    'Улитки',
    'Змея',
    'Ящерица'
];

// Обработка формы заказа
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Сбор данных
    $data = [
        'food_type' => Functions::sanitize($_POST['food_type'] ?? ''),
        'pet_type' => Functions::sanitize($_POST['pet_type'] ?? ''),
        'bags_count' => intval($_POST['bags_count'] ?? 0),
        'customer_name' => Functions::sanitize($_POST['customer_name'] ?? ''),
        'delivery_address' => Functions::sanitize($_POST['delivery_address'] ?? ''),
        'phone' => Functions::sanitize($_POST['phone'] ?? ''),
        'email' => Functions::sanitize($_POST['email'] ?? ''),
        'comments' => Functions::sanitize($_POST['comments'] ?? '')
    ];
    
    // Валидация
    if (empty($data['food_type']) || !in_array($data['food_type'], $food_types)) {
        $errors[] = 'Выберите тип корма из списка';
    }
    
    if (empty($data['pet_type']) || !in_array($data['pet_type'], $pet_types)) {
        $errors[] = 'Выберите тип животного из списка';
    }
    
    if ($data['bags_count'] < 1 || $data['bags_count'] > 100) {
        $errors[] = 'Количество мешков должно быть от 1 до 100';
    }
    
    if (empty($data['customer_name']) || strlen($data['customer_name']) < 2) {
        $errors[] = 'Введите корректное ФИО заказчика';
    }
    
    if (empty($data['delivery_address']) || strlen($data['delivery_address']) < 10) {
        $errors[] = 'Введите подробный адрес доставки';
    }
    
    if (empty($data['phone']) || !Functions::validatePhone($data['phone'])) {
        $errors[] = 'Введите корректный номер телефона';
    }
    
    if (!empty($data['email']) && !Functions::validateEmail($data['email'])) {
        $errors[] = 'Введите корректный email адрес';
    }
    
    // Если ошибок нет - сохраняем заказ
    if (empty($errors)) {
        $orderId = Functions::createOrder($data);
        if ($orderId) {
            $success = true;
            $_POST = []; // Очищаем форму
        } else {
            $errors[] = 'Ошибка при сохранении заказа. Попробуйте еще раз.';
        }
    }
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Оформление заказа - PetFood</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <!-- Шапка -->
    <header class="header">
        <div class="container">
            <nav class="navbar">
                <a href="index.php" class="logo">
                    <i class="fas fa-paw"></i>
                    <span>PetFood</span>
                </a>
                
                <ul class="nav-menu">
                    <li><a href="index.php"><i class="fas fa-home"></i> Главная</a></li>
                    <li><a href="index.php#products"><i class="fas fa-shopping-basket"></i> Продукция</a></li>
                    <li><a href="order.php" class="active"><i class="fas fa-cart-plus"></i> Заказать</a></li>
                    <li><a href="index.php#contacts"><i class="fas fa-phone"></i> Контакты</a></li>
                </ul>
                
                <div class="nav-actions">
                    <a href="index.php" class="btn btn-secondary">
                        <i class="fas fa-arrow-left"></i> На главную
                    </a>
                </div>
                
                <button class="menu-toggle">
                    <i class="fas fa-bars"></i>
                </button>
            </nav>
        </div>
    </header>

    <!-- Основной контент -->
    <main class="main-content">
        <div class="container">
            <div class="page-header">
                <h1><i class="fas fa-shopping-cart"></i> Оформление заказа</h1>
                <p>Заполните форму ниже для заказа корма для вашего питомца</p>
            </div>
            
            <?php if ($success): ?>
                <div class="alert alert-success">
                    <div class="alert-icon">
                        <i class="fas fa-check-circle"></i>
                    </div>
                    <div class="alert-content">
                        <h3>Заказ успешно оформлен!</h3>
                        <p>Ваш заказ №<?php echo $orderId; ?> принят в обработку. Мы свяжемся с вами в ближайшее время для подтверждения.</p>
                        <p>Вы можете <a href="order.php">оформить еще один заказ</a> или <a href="index.php">вернуться на главную</a>.</p>
                    </div>
                </div>
            <?php endif; ?>
            
            <?php if (!empty($errors)): ?>
                <div class="alert alert-error">
                    <div class="alert-icon">
                        <i class="fas fa-exclamation-circle"></i>
                    </div>
                    <div class="alert-content">
                        <h3>Ошибки при заполнении формы:</h3>
                        <ul>
                            <?php foreach ($errors as $error): ?>
                                <li><?php echo $error; ?></li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                </div>
            <?php endif; ?>
            
            <div class="order-form-container">
                <form method="POST" action="" class="order-form" id="orderForm">
                    <div class="form-grid">
                        <div class="form-group">
                            <label for="food_type" class="required">
                                <i class="fas fa-utensils"></i> Вид корма
                            </label>
                            <select id="food_type" name="food_type" required>
                                <option value="">-- Выберите тип корма --</option>
                                <?php foreach ($food_types as $type): ?>
                                    <option value="<?php echo $type; ?>"
                                        <?php echo (isset($_POST['food_type']) && $_POST['food_type'] == $type) ? 'selected' : ''; ?>>
                                        <?php echo $type; ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        
                        <div class="form-group">
                            <label for="pet_type" class="required">
                                <i class="fas fa-paw"></i> Домашнее животное
                            </label>
                            <select id="pet_type" name="pet_type" required>
                                <option value="">-- Выберите животное --</option>
                                <?php foreach ($pet_types as $pet): ?>
                                    <option value="<?php echo $pet; ?>"
                                        <?php echo (isset($_POST['pet_type']) && $_POST['pet_type'] == $pet) ? 'selected' : ''; ?>>
                                        <?php echo $pet; ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        
                        <div class="form-group">
                            <label for="bags_count" class="required">
                                <i class="fas fa-box"></i> Количество мешков
                            </label>
                            <input type="number" id="bags_count" name="bags_count" 
                                   min="1" max="100" value="<?php echo isset($_POST['bags_count']) ? $_POST['bags_count'] : '1'; ?>" 
                                   required>
                            <small>1 мешок = 15 кг</small>
                        </div>
                        
                        <div class="form-group">
                            <label for="customer_name" class="required">
                                <i class="fas fa-user"></i> ФИО Заказчика
                            </label>
                            <input type="text" id="customer_name" name="customer_name" 
                                   value="<?php echo isset($_POST['customer_name']) ? $_POST['customer_name'] : ''; ?>" 
                                   placeholder="Иванов Иван Иванович" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="phone" class="required">
                                <i class="fas fa-phone"></i> Телефон заказчика
                            </label>
                            <input type="tel" id="phone" name="phone" 
                                   value="<?php echo isset($_POST['phone']) ? $_POST['phone'] : ''; ?>" 
                                   placeholder="+7 (999) 123-45-67" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="email">
                                <i class="fas fa-envelope"></i> Email (необязательно)
                            </label>
                            <input type="email" id="email" name="email" 
                                   value="<?php echo isset($_POST['email']) ? $_POST['email'] : ''; ?>" 
                                   placeholder="ваш@email.ru">
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label for="delivery_address" class="required">
                            <i class="fas fa-map-marker-alt"></i> Адрес доставки
                        </label>
                        <textarea id="delivery_address" name="delivery_address" 
                                  rows="3" 
                                  placeholder="Город, улица, дом, квартира, подъезд, этаж, код домофона..." 
                                  required><?php echo isset($_POST['delivery_address']) ? $_POST['delivery_address'] : ''; ?></textarea>
                    </div>
                    
                    <div class="form-group">
                        <label for="comments">
                            <i class="fas fa-comment"></i> Комментарии к заказу
                        </label>
                        <textarea id="comments" name="comments" 
                                  rows="3" 
                                  placeholder="Дополнительные пожелания, удобное время доставки и т.д."><?php echo isset($_POST['comments']) ? $_POST['comments'] : ''; ?></textarea>
                    </div>
                    
                    <div class="form-footer">
                        <div class="form-agreement">
                            <label class="checkbox">
                                <input type="checkbox" required>
                                <span>Я согласен с <a href="#">политикой конфиденциальности</a> и даю согласие на обработку персональных данных</span>
                            </label>
                        </div>
                        
                        <button type="submit" class="btn btn-primary btn-large">
                            <i class="fas fa-paper-plane"></i> Отправить заказ
                        </button>
                    </div>
                </form>
                
                <div class="order-info">
                    <div class="info-card">
                        <h3><i class="fas fa-info-circle"></i> Информация о заказе</h3>
                        <ul>
                            <li><i class="fas fa-shipping-fast"></i> Бесплатная доставка при заказе от 2000₽</li>
                            <li><i class="fas fa-clock"></i> Доставка в день заказа до 18:00</li>
                            <li><i class="fas fa-shield-alt"></i> Гарантия качества всех товаров</li>
                            <li><i class="fas fa-credit-card"></i> Оплата при получении</li>
                            <li><i class="fas fa-headset"></i> Техподдержка: +7 (495) 123-45-67</li>
                        </ul>
                    </div>
                    
                    <div class="info-card">
                        <h3><i class="fas fa-question-circle"></i> Частые вопросы</h3>
                        <div class="faq">
                            <div class="faq-item">
                                <h4>Как быстро доставляют заказы?</h4>
                                <p>Заказы, оформленные до 15:00, доставляем в тот же день. После 15:00 - на следующий день.</p>
                            </div>
                            <div class="faq-item">
                                <h4>Можно ли изменить заказ?</h4>
                                <p>Да, позвоните по телефону поддержки для изменения заказа.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>

    <!-- Подвал -->
    <footer class="footer">
        <div class="container">
            <div class="footer-content">
                <div class="footer-section">
                    <a href="index.php" class="logo">
                        <i class="fas fa-paw"></i>
                        <span>PetFood</span>
                    </a>
                    <p>Заказ кормов для животных с доставкой</p>
                </div>
                
                <div class="footer-section">
                    <h3>Контакты</h3>
                    <ul>
                        <li><i class="fas fa-phone"></i> +7 (495) 123-45-67</li>
                        <li><i class="fas fa-clock"></i> Ежедневно 9:00-21:00</li>
                    </ul>
                </div>
            </div>
            
            <div class="footer-bottom">
                <p>&copy; 2024 PetFood. Форма заказа кормов для животных.</p>
            </div>
        </div>
    </footer>

    <script src="js/main.js"></script>
    <script src="js/validate.js"></script>
</body>
</html>