-- Если база данных уже создана как y99126qa_petfood

-- Таблица заказов
CREATE TABLE IF NOT EXISTS y99126qa_petfood.orders (
    id INT PRIMARY KEY AUTO_INCREMENT,
    food_type VARCHAR(100) NOT NULL,
    pet_type VARCHAR(100) NOT NULL,
    bags_count INT NOT NULL CHECK (bags_count >= 1 AND bags_count <= 100),
    customer_name VARCHAR(200) NOT NULL,
    delivery_address TEXT NOT NULL,
    phone VARCHAR(20) NOT NULL,
    email VARCHAR(100),
    comments TEXT,
    order_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    status ENUM('new', 'processing', 'completed', 'cancelled') DEFAULT 'new',
    INDEX idx_status (status),
    INDEX idx_order_date (order_date),
    INDEX idx_customer_name (customer_name(50)),
    INDEX idx_phone (phone)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Таблица пользователей (администраторы)
CREATE TABLE IF NOT EXISTS y99126qa_petfood.users (
    id INT PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(50) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    email VARCHAR(100),
    role ENUM('admin', 'manager') DEFAULT 'manager',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    last_login TIMESTAMP NULL,
    INDEX idx_username (username)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Вставляем тестового администратора (пароль: admin123)
INSERT IGNORE INTO y99126qa_petfood.users (username, password_hash, email, role) VALUES 
('admin', MD5('admin123'), 'admin@petfood.ru', 'admin');