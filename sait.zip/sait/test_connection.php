<?php
// test_connection.php
$host = 'localhost';
$dbname = 'y99126qa_petfood';
$username = 'y99126qa_petfood';
$password = '@Rjkktl;2';

try {
    $conn = new mysqli($host, $username, $password, $dbname);
    
    if ($conn->connect_error) {
        die("Ошибка подключения: " . $conn->connect_error);
    }
    
    echo "Подключение к базе данных успешно!<br>";
    
    // Проверяем таблицы
    $result = $conn->query("SHOW TABLES");
    echo "Таблицы в базе данных:<br>";
    while ($row = $result->fetch_array()) {
        echo "- " . $row[0] . "<br>";
    }
    
    $conn->close();
} catch(Exception $e) {
    die("Ошибка: " . $e->getMessage());
}
?>