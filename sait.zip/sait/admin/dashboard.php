<?php
require_once '../includes/database.php';
require_once '../includes/functions.php';

// Проверка авторизации
if (!Functions::isAdminLoggedIn()) {
    header('Location: index.php');
    exit();
}

$conn = Database::getConnection();

// Обработка действий
if (isset($_GET['action'])) {
    $action = $_GET['action'];
    
    switch ($action) {
        case 'delete':
            if (isset($_GET['id'])) {
                $id = intval($_GET['id']);
                Functions::deleteOrder($id);
            }
            break;
            
        case 'update_status':
            if (isset($_GET['id']) && isset($_GET['status'])) {
                $id = intval($_GET['id']);
                $status = Functions::sanitize($_GET['status']);
                Functions::updateOrderStatus($id, $status);
            }
            break;
            
        case 'logout':
            Functions::adminLogout();
            header('Location: index.php');
            exit();
    }
}

// Получение фильтров
$filters = [
    'status' => $_GET['status'] ?? '',
    'search' => $_GET['search'] ?? '',
    'date_from' => $_GET['date_from'] ?? '',
    'date_to' => $_GET['date_to'] ?? ''
];

// Получение заказов
$orders = Functions::getOrders($filters);
$stats = Functions::getStats();
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Панель управления - PetFood</title>
    <link rel="stylesheet" href="assets/css/admin.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <!-- Навигация -->
    <nav class="admin-nav">
        <div class="nav-container">
            <div class="nav-brand">
                <i class="fas fa-user-shield"></i>
                <span>PetFood Admin</span>
            </div>
            
            <div class="nav-user">
                <i class="fas fa-user-circle"></i>
                <span><?php echo $_SESSION['admin_username']; ?></span>
                <a href="?action=logout" class="logout-btn">
                    <i class="fas fa-sign-out-alt"></i> Выйти
                </a>
            </div>
        </div>
    </nav>

    <!-- Основной контент -->
    <div class="admin-container">
        <!-- Боковое меню -->
        <aside class="sidebar">
            <ul class="sidebar-menu">
                <li class="active">
                    <a href="dashboard.php">
                        <i class="fas fa-tachometer-alt"></i> Дашборд
                    </a>
                </li>
                <li>
                    <a href="dashboard.php?status=new">
                        <i class="fas fa-inbox"></i> Новые заказы
                        <?php if ($stats['by_status']['new'] ?? 0 > 0): ?>
                            <span class="badge badge-primary"><?php echo $stats['by_status']['new']; ?></span>
                        <?php endif; ?>
                    </a>
                </li>
                <li>
                    <a href="dashboard.php?status=processing">
                        <i class="fas fa-cog"></i> В обработке
                    </a>
                </li>
                <li>
                    <a href="dashboard.php?status=completed">
                        <i class="fas fa-check-circle"></i> Завершенные
                    </a>
                </li>
                <li>
                    <a href="dashboard.php">
                        <i class="fas fa-list"></i> Все заказы
                    </a>
                </li>
                <li>
                    <a href="../index.php" target="_blank">
                        <i class="fas fa-external-link-alt"></i> Перейти на сайт
                    </a>
                </li>
            </ul>
        </aside>

        <!-- Основная область -->
        <main class="main-content">
            <!-- Статистика -->
            <div class="stats-grid">
                <div class="stat-card">
                    <div class="stat-icon">
                        <i class="fas fa-shopping-cart"></i>
                    </div>
                    <div class="stat-content">
                        <h3>Всего заказов</h3>
                        <p class="stat-number"><?php echo $stats['total_orders']; ?></p>
                    </div>
                </div>
                
                <div class="stat-card">
                    <div class="stat-icon">
                        <i class="fas fa-clock"></i>
                    </div>
                    <div class="stat-content">
                        <h3>Сегодня</h3>
                        <p class="stat-number"><?php echo $stats['today_orders']; ?></p>
                    </div>
                </div>
                
                <div class="stat-card">
                    <div class="stat-icon">
                        <i class="fas fa-box"></i>
                    </div>
                    <div class="stat-content">
                        <h3>Всего мешков</h3>
                        <p class="stat-number"><?php echo $stats['total_bags']; ?></p>
                    </div>
                </div>
                
                <div class="stat-card">
                    <div class="stat-icon">
                        <i class="fas fa-check-circle"></i>
                    </div>
                    <div class="stat-content">
                        <h3>Завершено</h3>
                        <p class="stat-number"><?php echo $stats['by_status']['completed'] ?? 0; ?></p>
                    </div>
                </div>
            </div>

            <!-- Фильтры -->
            <div class="filters-card">
                <h3><i class="fas fa-filter"></i> Фильтры заказов</h3>
                <form method="GET" class="filters-form">
                    <div class="filter-row">
                        <div class="filter-group">
                            <label for="search">Поиск:</label>
                            <input type="text" id="search" name="search" 
                                   value="<?php echo htmlspecialchars($filters['search']); ?>"
                                   placeholder="ФИО, телефон, адрес...">
                        </div>
                        
                        <div class="filter-group">
                            <label for="status">Статус:</label>
                            <select id="status" name="status">
                                <option value="">Все статусы</option>
                                <option value="new" <?php echo $filters['status'] == 'new' ? 'selected' : ''; ?>>Новый</option>
                                <option value="processing" <?php echo $filters['status'] == 'processing' ? 'selected' : ''; ?>>В обработке</option>
                                <option value="completed" <?php echo $filters['status'] == 'completed' ? 'selected' : ''; ?>>Завершен</option>
                                <option value="cancelled" <?php echo $filters['status'] == 'cancelled' ? 'selected' : ''; ?>>Отменен</option>
                            </select>
                        </div>
                        
                        <div class="filter-group">
                            <label for="date_from">От:</label>
                            <input type="date" id="date_from" name="date_from" 
                                   value="<?php echo $filters['date_from']; ?>">
                        </div>
                        
                        <div class="filter-group">
                            <label for="date_to">До:</label>
                            <input type="date" id="date_to" name="date_to" 
                                   value="<?php echo $filters['date_to']; ?>">
                        </div>
                        
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-search"></i> Применить
                        </button>
                        
                        <a href="dashboard.php" class="btn btn-secondary">
                            <i class="fas fa-redo"></i> Сбросить
                        </a>
                    </div>
                </form>
            </div>

            <!-- Таблица заказов -->
            <div class="orders-card">
                <div class="card-header">
                    <h3><i class="fas fa-list"></i> Список заказов</h3>
                    <span class="badge"><?php echo count($orders); ?> заказов</span>
                </div>
                
                <?php if (empty($orders)): ?>
                    <div class="empty-state">
                        <i class="fas fa-inbox"></i>
                        <h4>Заказы не найдены</h4>
                        <p>Попробуйте изменить параметры фильтрации</p>
                    </div>
                <?php else: ?>
                    <div class="table-responsive">
                        <table class="orders-table">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Дата</th>
                                    <th>Клиент</th>
                                    <th>Телефон</th>
                                    <th>Корм / Животное</th>
                                    <th>Мешки</th>
                                    <th>Адрес</th>
                                    <th>Статус</th>
                                    <th>Действия</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($orders as $order): ?>
                                    <tr>
                                        <td class="order-id">#<?php echo $order['id']; ?></td>
                                        <td class="order-date">
                                            <?php echo date('d.m.Y', strtotime($order['order_date'])); ?><br>
                                            <small><?php echo date('H:i', strtotime($order['order_date'])); ?></small>
                                        </td>
                                        <td class="order-customer">
                                            <strong><?php echo htmlspecialchars($order['customer_name']); ?></strong>
                                            <?php if (!empty($order['email'])): ?>
                                                <br><small><?php echo htmlspecialchars($order['email']); ?></small>
                                            <?php endif; ?>
                                        </td>
                                        <td class="order-phone">
                                            <a href="tel:<?php echo htmlspecialchars($order['phone']); ?>">
                                                <?php echo htmlspecialchars($order['phone']); ?>
                                            </a>
                                        </td>
                                        <td class="order-details">
                                            <small><?php echo htmlspecialchars($order['food_type']); ?></small><br>
                                            <span class="pet-type"><?php echo htmlspecialchars($order['pet_type']); ?></span>
                                        </td>
                                        <td class="order-bags">
                                            <span class="badge badge-secondary"><?php echo $order['bags_count']; ?> шт</span>
                                        </td>
                                        <td class="order-address" title="<?php echo htmlspecialchars($order['delivery_address']); ?>">
                                            <?php echo mb_substr(htmlspecialchars($order['delivery_address']), 0, 30); ?>...
                                        </td>
                                        <td class="order-status">
                                            <span class="status-badge status-<?php echo $order['status']; ?>">
                                                <?php
                                                $statusLabels = [
                                                    'new' => 'Новый',
                                                    'processing' => 'В работе',
                                                    'completed' => 'Завершен',
                                                    'cancelled' => 'Отменен'
                                                ];
                                                echo $statusLabels[$order['status']];
                                                ?>
                                            </span>
                                        </td>
                                        <td class="order-actions">
                                            <div class="action-buttons">
                                                <select onchange="updateStatus(<?php echo $order['id']; ?>, this.value)" 
                                                        class="status-select">
                                                    <option value="new" <?php echo $order['status'] == 'new' ? 'selected' : ''; ?>>Новый</option>
                                                    <option value="processing" <?php echo $order['status'] == 'processing' ? 'selected' : ''; ?>>В работе</option>
                                                    <option value="completed" <?php echo $order['status'] == 'completed' ? 'selected' : ''; ?>>Завершить</option>
                                                    <option value="cancelled" <?php echo $order['status'] == 'cancelled' ? 'selected' : ''; ?>>Отменить</option>
                                                </select>
                                                
                                                <a href="javascript:void(0)" 
                                                   onclick="showOrderDetails(<?php echo $order['id']; ?>)" 
                                                   class="btn-action btn-view" 
                                                   title="Просмотр">
                                                    <i class="fas fa-eye"></i>
                                                </a>
                                                
                                                <a href="?action=delete&id=<?php echo $order['id']; ?>" 
                                                   class="btn-action btn-delete" 
                                                   title="Удалить"
                                                   onclick="return confirm('Удалить заказ #<?php echo $order['id']; ?>?')">
                                                    <i class="fas fa-trash"></i>
                                                </a>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>
        </main>
    </div>

    <!-- Модальное окно для деталей заказа -->
    <div id="orderDetailsModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h3>Детали заказа</h3>
                <button class="modal-close">&times;</button>
            </div>
            <div class="modal-body" id="orderDetailsContent">
                <!-- Детали заказа будут загружены здесь -->
            </div>
        </div>
    </div>

    <script>
        function updateStatus(orderId, status) {
            if (confirm('Изменить статус заказа?')) {
                window.location.href = `?action=update_status&id=${orderId}&status=${status}`;
            }
        }
        
        function showOrderDetails(orderId) {
            // Здесь можно реализовать AJAX-запрос для получения деталей заказа
            // или просто показать информацию из таблицы
            alert('Детали заказа #' + orderId + ' будут загружены здесь.\nДля реализации нужно добавить AJAX.');
        }
        
        // Модальное окно
        const modal = document.getElementById('orderDetailsModal');
        const closeBtn = modal.querySelector('.modal-close');
        
        closeBtn.onclick = function() {
            modal.style.display = 'none';
        }
        
        window.onclick = function(event) {
            if (event.target == modal) {
                modal.style.display = 'none';
            }
        }
    </script>
</body>
</html>