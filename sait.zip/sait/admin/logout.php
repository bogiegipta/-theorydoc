<?php
require_once '../includes/database.php';
require_once '../includes/functions.php';

Functions::adminLogout();
header('Location: index.php');
exit();
?>